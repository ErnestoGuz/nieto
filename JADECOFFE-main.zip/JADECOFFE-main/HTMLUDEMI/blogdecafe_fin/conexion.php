<?php
    $servidor='localhost';
    $usuario='root';
    $password='';
    $database='motos';

    $conexion= mysqli_connect($servidor,$usuario,$password,$database);
?>